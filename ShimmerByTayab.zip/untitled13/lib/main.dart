import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Shimmer Demo',
      debugShowCheckedModeBanner: false, // Remove debug banner
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Shimmer Demo',
          textAlign: TextAlign.center, // Center the text
        ),
        centerTitle: true, // Center the title
      ),
      body: ListView.builder(
        itemCount: 10,
        itemBuilder: (context, index) {
          return ShimmerEffect();
        },
      ),
    );
  }
}

class ShimmerEffect extends StatefulWidget {
  @override
  _ShimmerEffectState createState() => _ShimmerEffectState();
}

class _ShimmerEffectState extends State<ShimmerEffect> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: Duration(seconds: 1),
      vsync: this,
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 10.0, horizontal: 16.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            width: 70.0,
            height: 70.0,
            color: Colors.grey[300],
            margin: EdgeInsets.only(right: 16.0),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(35.0),
              child: AnimatedBuilder(
                animation: _controller,
                builder: (BuildContext context, Widget? child) {
                  return Container(
                    color: ColorTween(
                      begin: Colors.grey[300],
                      end: Colors.grey[100],
                    ).evaluate(_controller),
                  );
                },
              ),
            ),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  height: 16.0,
                  width: double.infinity,
                  margin: EdgeInsets.only(bottom: 8.0),
                  color: ColorTween(
                    begin: Colors.grey[300],
                    end: Colors.grey[100],
                  ).evaluate(_controller),
                ),
                Container(
                  height: 16.0,
                  width: 200.0,
                  margin: EdgeInsets.only(bottom: 8.0),
                  color: ColorTween(
                    begin: Colors.grey[300],
                    end: Colors.grey[100],
                  ).evaluate(_controller),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
